/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbconnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SPY
 */
public class DBconnect {  
      
    public static Connection Connect() throws ClassNotFoundException
    {
        Connection con = null;
        
        String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=superMarket;user=sa;password=yasoda@1998";
        
        try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con=DriverManager.getConnection(connectionURL);
            if(con!=null)
            {
                System.out.println("Connected");
            }
            else
            {
                System.out.println("Error while Connecting");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DBconnect.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
    
}
